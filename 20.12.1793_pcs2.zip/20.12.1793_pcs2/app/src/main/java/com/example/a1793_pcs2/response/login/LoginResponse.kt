package com.example.a1793_pcs2.response.login

class LoginResponse (
    val success:Boolean,
    val message:String,
    val data:Data
)